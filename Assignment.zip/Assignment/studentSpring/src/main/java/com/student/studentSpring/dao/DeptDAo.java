package com.student.studentSpring.dao;

import java.util.List;

import com.student.studentSpring.dto.Department;
import com.student.studentSpring.dto.Employee;
import com.student.studentSpring.repository.DepartmentRepository;

public class DeptDAo {
	
	DepartmentRepository repo;
	
	public Department saveDept(Department dept)
	{
		return repo.save(dept);
	}
	
	
	public List<Department> getAll()
	{
		return repo.findAll();
	}


	

}
