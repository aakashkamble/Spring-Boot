package com.student.studentSpring.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.student.studentSpring.dto.Department;

public interface DepartmentRepository  extends JpaRepository<Department, Integer>{

}
