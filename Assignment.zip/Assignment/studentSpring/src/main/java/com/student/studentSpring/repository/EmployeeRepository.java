package com.student.studentSpring.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.student.studentSpring.dto.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

}
